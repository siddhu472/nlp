#!/sw/bin/python

import math
import sys
import glob
import pickle
from dicts import DefaultDict
from sets import Set 

# In the documentation and variable names below "class" is the same
# as "category"

vocab = Set() 

def naivebayes (dirs):
    """Train and return a naive Bayes classifier.  
    The datastructure returned is an array of tuples, one tuple per
    class; each tuple contains the class name (same as dir name)
    and the multinomial distribution over words associated with
    the class"""
    classes = []
 
    for dir in dirs:
	countdict = files2countdict(glob.glob(dir+"/*"))
	# Here turn the "countdict" dictionary of word counts into
	# into a dictionary of smoothed word probabilities
	l = 1
	totalWordsInClass = 0 ; 
	totalWordsInClassSmooth = 0 ; 
	# laplace smoothing 
	for key in countdict : 
		totalWordsInClass += countdict[key] 
	totalWordsInClassSmooth = totalWordsInClass + l*len(vocab) 
	for key in countdict : 
		countdict[key] = float(countdict[key]+l)/totalWordsInClassSmooth 
	classes.append((dir,countdict))
    return classes

def classify (classes, filename):
    """Given a trained naive Bayes classifier returned by naivebayes(), and
    the filename of a test document, d, return an array of tuples, each
    containing a class label; the array is sorted by log-probability 
    of the class, log p(c|d)"""
    answers = []
    #print 'Classifying', filename
    for c in classes:
	
	score = 0
	for word in open(filename).read().split():
	    word = word.lower()
            if word in vocab : 
	    	score += math.log(c[1].get(word,1))
	answers.append((score,c[0]))
    answers.sort()
    return answers

def files2countdict (files):
    """Given an array of filenames, return a dictionary with keys
    being the space-separated, lower-cased words, and the values being
    the number of times that word occurred in the files."""
    d = DefaultDict(0)
    for file in files:
	for word in open(file).read().split():
            if word.lower() not in  vocab: 
		vocab.add(word.lower())
	    d[word.lower()] += 1
    return d
	
hamacc = 0 
spamacc = 0 

if __name__ == '__main__':
    print 'argv', sys.argv
    print "Usage:", sys.argv[0], "classdir1 classdir2 [classdir3...] ham_test spam_test"
    dirs = sys.argv[1:-2]
    spamtestfile = sys.argv[-1]
    hamtestfile = sys.argv[-2]
    nb = naivebayes (dirs)
    spamtestfile = glob.glob(spamtestfile+"/*")  
    hamtestfile = glob.glob(hamtestfile+"/*") 
    spamcount = 0 
    hamcount = 0 
    for file in spamtestfile : 
	 spamcount+=1 
      	 if classify(nb,file)[0][1] == "spam" : 
		spamacc+=1 ;

    for file in hamtestfile :
	hamcount+=1 
	if classify(nb,file)[0][1] == "ham" : 
		hamacc+=1  

print "STATISTICS" 
print "Size of the Vocabulary:" + str(len(vocab)) 
print "Number of Spam files:" + str(spamcount) 
print "Number of Ham  files:" + str(hamcount) 
print "Number of spam identified as spam:" + str(spamacc) 
print "Number of Ham identified as ham:" + str(hamacc) 
print "Spam accuracy:" + str(float(spamacc)/spamcount) 
print "ham accuracy:" + str(float(hamacc)/spamcount) 
accuracy = float(spamacc+hamacc)/(spamcount+hamcount)
print "Overall accuracy:" + str(accuracy)
recall = float(hamacc)/hamcount 
print "Recall" + str(recall)
precision = float (hamacc)/(hamacc+(spamcount-spamacc))
print "Precision:" + str(precision)
print "F1 Score:" + str((2*precision*recall)/(precision+recall)) 
