from dicts import DefaultDict

def bigrams(words):
    """Given an array of words, returns a dictionary of dictionaries,
    containing occurrence counts of bigrams."""
    d = DefaultDict(DefaultDict(0))
    for (w1, w2) in zip([None] + words, words + [None]):
        d[w1][w2] += 1
 
    unigram = DefaultDict(0) ; 
    for word1 in d :        
      for word2 in d[word1]: 
	  unigram[word1]+= d[word1][word2] 

    print len(unigram) 
    #laplace smoothing 
    l=1
   
    for word1 in d : 
	for word2 in d[word1]:  
		d[word1][word2] = (float(d[word1][word2])+l)/(unigram[word1]+ (l*len(unigram)))
    return d 
def file2bigrams(filename):
    return bigrams(open(filename).read().split())

d = file2bigrams("gettysburgh")
print "The phrase 'world will' occurs with probability", d['world']['will']
print "The phrase 'shall not' occurs with probability", d['shall']['not']
